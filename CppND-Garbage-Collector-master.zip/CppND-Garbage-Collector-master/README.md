# CppND-Garbage-Collector
The final project for this Memory Management course is to implement your own version of a smart pointer. You can think of this as implementing your own garbage collector, to use a concept from other programming languages. Building this project will help you understand both how to work with pointers and references, and also why smart pointers are so important to modern C++ programming. Complete the implementations and verify that your implementation does not have any memory leaks!

## Project TODO List:
- Complete `Pointer` constructor
- Complete `Pointer` `operator==`
- Complete `Pointer` destructor
- Complete `PtrDetails` class



'We can conclude that when a pointer is added to a memory block its reference count is increased, and likewise, when a pointer is removed, it is decreased. When the reference count becomes zero, that is when the memory can be deallocated.'


Pointer is considered a template class and three operators are overloaded. The '*','->','[]' operators. 


The Iter Class

Memory to which Pointer is pointing to is accessed with the * and -> operators. The Iterator class allows us use pointer arithmetic. Iterator overloads all pointer operators necessary for pointer arithmetic. The purpose of Iterator is to traverse through the list elements of dynamically allocated arrays. Another purpose is for bound checking. An Iterator from Pointer is acquired by calling functions begin() and end().



std::unique_ptr<int> ptr1 (new int);
std::unique_ptr<int> ptr2 = std::move(ptr1);

std::shared_ptr<int> ptr1 (new int(20));
std::shared_ptr<int> ptr2 = ptr1;

#include<iostream>
#include<memory>
#include<vector>

class testUnique {
    std::unique_ptr<int> ptr;
    public:
    testUnique(int var): ptr(new int(var)) {}
    testUnique(): ptr(new int(0)) {}

    int getAttr() const {
        return *ptr;
    }
};


int main() {
    std::vector<std::shared_ptr<testUnique> > container;
    container.push_back(std::make_shared<testUnique> (testUnique(2)));
    container.push_back(std::make_shared<testUnique> (testUnique(52)));

    for (int i = 0; i< container.size(); i++) {
        std::cout<<&container[i]<<" "<<(*container[i]).getAttr()<<std::endl;
    }
    
    return 0;
}





#include<iostream>
#include<memory>

using namespace std;

class A {
    public:
    void classMethod() {
        cout<<"A::classMethod"<<endl;
    }
};

int main() {
    shared_ptr<A> p1 (new A)l
    cout<<p1.get()<<endl;
    shared_ptr<A> p2 (p1)
    cout<<p1.get()<<endl;
    cout<<p2.get()<<endl;

    cout<<p1.use_count()<<endl;
    cout<<p2.use_count()<<endl;

    p1.reset();

    cout<<p1.get()<<endl;
    cout<<p2.use_count()<<endl;
    cout<<p2.get()<<endl;

    return 0;
}

